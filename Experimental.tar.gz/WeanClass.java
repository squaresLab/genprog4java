import java.util.*;
import java.io.*;
public class WeanClass implements Serializable
{
	public String method="";
	public String location="";
	public ArrayList<String> statements = new ArrayList<String>();
}
