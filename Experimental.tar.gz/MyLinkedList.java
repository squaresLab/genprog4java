import java.util.*;
/**
 * This is an implementation of a singly linked, non-circular generic list where each node only has one link next and the list has a head and a tail linka linked list
 * The head and tail of MyLinkedList will always be empty
 * 
 * @author Yiwei Lyu
 */
public class MyLinkedList<E> implements Iterable<E>
{
    /**
     * This is a nested class that denotes each singly linked node in MyLinkedList
     */
    private static class Node<E>
    {
         /**
           * Constructor for a node
           * @param d the data stored
           * @param n the next node
           */
         public Node(E d, Node<E> n)
         {
             data=d;
             next=n;
         }
         //define the field that stores the data
         public E data;
         //define the link to the next node
         public Node<E> next;
    }

    //defines the private variable of list size
    private int size;
    //defines the private reference to the head node. It should always contain empty data
    private Node<E> head;
    //defines the private reference to the tail node. It should always contain empty data
    private Node<E> tail;
    
    /**
     * Constructor of class MyLinkedList
     * creates an empty MyLinkedList with head and tail
     */
    public MyLinkedList()
    {
        // initialise list size
        size = 0;
        // initializes the tail node
        tail = new Node<E>(null,null);
        // initializes the head node that is linked to the tail node
        head = new Node<E>(null,tail);
    }
    
    /**
     * This private method returns the nth linked node in MyLinkedList (starting from 0, so the 0th node would be the first node after the head)
     * 
     * @param n the location of the node
     * @return the nth node in MyLinkedList
     */
    private Node<E> getNode(int n)
    {
        //define p as the 0th element
        Node p = head.next;
        //use a for loop to get to the nth element
        for(int i = 0; i < n; i++)
        {
            p=p.next;
        }
        //returns the node
        return p;
    }
    
    /**
     * This method returns a new MyLinkedListIterator of MyLinkedList
     * @return a new MyLinkedListIterator on the first position
     */
    public Iterator<E> iterator()
    {
        return new MyLinkedListIterator();
    }

    /**
     * This method allows users to add data to the first location of MyLinkedList
     * 
     * @param x the data of type E that is added
     * @return true if the data is successfully added
     */
    public boolean addFirst(E x)
    {
        //creates a new node that contains x and is linked to the first element after the head
        Node<E> node = new Node<E>(x,head.next);
        //set the head's link to the new node
        head.next=node;
        //increments size
        size++;
        //returns true
        return true;
    }
    
    /**
     * This method allows users to add data to the end of MyLinkedList
     * 
     * @param x the data of type E that is added
     * @return true if the data is successfully added
     */
    public boolean addEnd(E x)
    {
        //adds x to the tail
        tail.data=x;
        //creates a new tail
        Node<E> newtail = new Node<E>(null,null);
        //Links old tail to new tail
        tail.next=newtail;
        //set the new tail as tail
        tail=newtail;
        //increments size
        size++;
        //returns true
        return true;
    }
    
    /**
     * This method allows users to get the nth element in MyLinkedList (starting from 0, so the 0th data would be the data stored in the node linked after the head) 
     * 
     * @param n the location of the data
     * @returns the data stored in the nth location in type E
     */
    public E get(int n)
    {
        return getNode(n).data;
    }
    
    /**
     * This method returns the size of the MyLinkedList
     * 
     * @return the size of the MyLinkedList
     */
    public int size()
    {
        return size;
    }
    
    /**
     * This method returns the data stored in this myLinkedList as an array
     * 
     * @returns the array of data stored in this myLinkedList
     */
    public Object[] returnArray()
    {
        //creates an empty array of type Object
        Object[] arr = new Object[size];
        //creates a new iterator for a
        Iterator<E> iterator = iterator();
        //copies each element
        for(int i = 0; i < size; i++)
        {
            arr[i]=iterator.next();
        }
        //returns the array
        return arr;
    }
    
    /**
     * This is a nested class that serves as an iterator of MyLinkedList<E>
     */
    private class MyLinkedListIterator implements Iterator<E>
    {
        //defines a private field that stores the current node. The default value is the first node after the head
        private Node<E> current = head.next;
        
        /**
         * This method determines if the iterator can go to the next element
         * 
         * @return whether the iterator can go to the next element or not
         */
        public boolean hasNext()
        {
            return (current!=tail);
        }
        
        /**
         * This method returns the data field in the current node and moves current to the next node
         * 
         * @throws NoSuchElementException if hasNext() is false
         * @return the data stored in the current node
         */
        public E next()
        {
            //check if the next element exists
            if(hasNext())
            {
                //stores the data
                E data = current.data;
                //moves current to the next node
                current=current.next;
                //returns the data
                return data;
            }
            else
            {
                //throws exception
                throw new NoSuchElementException();
            }
        }
    }
public static void main(String[] args)
{
Random rand = new Random();
for(int i = 0; i < 100; i++)
{
MyLinkedList<Integer> mll = new MyLinkedList<Integer>();
for(int j = 0; j < 100; j++)
{
mll.addFirst(rand.nextInt());
mll.addEnd(rand.nextInt());
}
}
}
}
