public class Typer
{
public static int typer(Object x)
{
return 0;
}
public static int typer(long x)
{
return 1;
}
public static int typer(double x)
{
return 2;
}
public static void main(String[] args)
{
System.out.println(typer(70));
}
public static int typer(int x)
{
return 1;
}
public static int typer(char x)
{
return 1;
}
public static int typer(float x)
{
return 1;
}
}
