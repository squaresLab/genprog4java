import java.io.*;
import java.util.*;

public class WeanParse
{
	public static void main(String[] args) throws IOException
	{
		String fn = args[0];
                String debug = args[1];
		Scanner input = new Scanner(new File(fn));
		ArrayList<WeanClass> classes = new ArrayList<WeanClass>();
		WeanClass current = null;
		while(input.hasNext())
		{
			String line = input.nextLine();
			if(line.equals("Exiting Daikon."))break;
			if(line.length()>=20&&line.substring(0,20).equals("===================="))
			{
				if(current!=null)classes.add(current);
				current = new WeanClass();
				line = input.nextLine();
				if(line.substring(line.length()-7).equals(":::EXIT"))
				{
					current.location="EXIT";
					current.method=line.substring(0,line.length()-7);
				}
				else if(line.substring(line.length()-8).equals(":::ENTER"))
				{
					current.location="ENTER";
					current.method=line.substring(0,line.length()-8);
				}
				else if(line.substring(line.length()-9).equals(":::OBJECT"))
				{
					current.location="OBJECT";
					current.method=line.substring(0,line.length()-9);
				}
				else current = null;

			}
			else if(current!=null)
			{
				current.statements.add(line);
			}
		}
		if(current!=null)classes.add(current);
		//System.out.println(classes.size());
		if(debug.equals("DEBUG"))
		{
			PrintWriter writer = new PrintWriter( new BufferedWriter( new FileWriter( fn+".twt" )));
			for(WeanClass w : classes)
			{
				writer.println("Method: "+w.method);
				writer.println("Location: "+w.location);
				for(String s : w.statements)
				{
					writer.println(s);
				}
				writer.println("");
			}
			writer.close();
		}
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fn+".ywl"));
		out.writeObject(classes);
		out.flush();
		out.close();




	}
}


