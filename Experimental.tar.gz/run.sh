#!/usr/lib/bin

FILENAME=$1

java daikon.Daikon $FILENAME.dtrace.gz > $FILENAME.wean 
java -cp .:$CLASSPATH WeanParse $FILENAME.wean DEBUG 
