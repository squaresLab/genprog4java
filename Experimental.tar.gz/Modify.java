import javassist.*;
import java.io.*;
import java.util.*;

public class Modify
{
	public static void main(String[] args) throws Exception
	{
		String fn = args[0];
		ClassPool pool = ClassPool.getDefault();
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fn+".wean.ywl"));
		ArrayList<WeanClass> classes = (ArrayList<WeanClass>) ois.readObject();
		ois.close();
		for(WeanClass w : classes)
		{
			int varnum = 0;
			if(w.location.equals("OBJECT"))continue;
			int id = w.method.indexOf('.');
			int paren = w.method.indexOf('(');
			if(id<0)continue;
			CtClass c = null;
			CtMethod m = null;
			try{
				c = pool.get(w.method.substring(0,id));
				m = c.getDeclaredMethod(w.method.substring(id+1,paren));
			}catch(Exception e){System.out.println("Skipped by invalid name: "+w.method);continue;}
			for(String ss : w.statements)
			{
				String s = changereturn(ss);
 				s=changearg(s);
				if(s.indexOf("getName()")>=0)continue;
				if(w.location.equals("ENTER"))
				{

					try{m.insertBefore("{System.out.println("+s+");System.out.println(\""+s+"\");}");System.out.println("good: "+s);}
					catch(Exception e){System.out.println("Skipped by invalid syntax: "+s+" "+e.getMessage());}
				}
				else
				{
					int origloc = s.indexOf("orig(");
					if(origloc<0){
						try{m.insertAfter("{System.out.println("+s+");System.out.println(\""+s+"\");}");System.out.println("good: "+s);}
						catch(Exception e){System.out.println("Skipped by invalid syntax: "+s+" "+e.getMessage());}
					}
					else
					{
						int origend = s.substring(origloc+5).indexOf(')')+origloc+5;
						try{   
							varnum++;
							String var = s.substring(origloc+5,origend);
							String rep = s.substring(0, origloc)+"var"+varnum+s.substring(origend+1);
							String repint = s.substring(0, origloc)+"it"+varnum+".longValue()"+s.substring(origend+1);
							m.addLocalVariable("var"+varnum,pool.get("java.lang.Object"));
							m.addLocalVariable("it"+varnum,pool.get("java.lang.Long"));
							try{
								m.insertBefore("var"+varnum+"=(Typer.typer("+var+")==0)?(Object)"+var+":null;");
								//m.insertBefore("it"+varnum+"=(Typer.typer("+var+")==0)?null:new Long("+var+");");
								m.insertAfter("{System.out.println("+rep+");System.out.println(\""+s+"\");}");System.out.println("good: "+s);
							}
							catch(Exception e)
							{
								m.insertBefore("it"+varnum+"=new Long((long)"+var+");");
								m.insertAfter("{System.out.println("+repint+");System.out.println(\""+s+"\");}");System.out.println("good: "+s);
							}
						}
						catch(Exception e){System.out.println("Skipped by invalid syntax: "+s+" "+e.getMessage());}

					}
				}
			}
			c.writeFile();
			c.defrost();
		}
	}
	public static String changearg(String s)
	{
		int a = s.indexOf("arg");
		if(a<0)return s;
		return changearg(s.substring(0,a)+"$"+(Integer.parseInt(s.substring(a+3,a+4))+1)+s.substring(a+4));
	}
	public static String changereturn(String s)
	{
		int a = s.indexOf("return");
		int b = s.indexOf("return elements");
		int c = s.indexOf(" == []");
		int d = s.indexOf("[]");
		int e = s.indexOf(".toString.length");
		if(a<0&&b<0&&c<0&&d<0&&e<0)return s;
		if(e>=0) return changereturn(s.substring(0,e)+".toString().length()"+s.substring(e+16));
		if(c>=0) return changereturn(s.substring(0,c)+".length == 0"+s.substring(c+6));
		if(d>=0) return changereturn(s.substring(0,d)+s.substring(d+2));
		if(b>=0)
		{
			return changereturn(s.substring(0,b)+"$_"+s.substring(b+15));
		}
		else
		{
			return changereturn(s.substring(0,a)+"$_"+s.substring(a+6));
		}
	}
}
